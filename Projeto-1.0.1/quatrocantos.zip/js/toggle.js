$(document).ready(function(){
  $(".toggle").click(function(){
  $("#links").toggle();
  });
});
